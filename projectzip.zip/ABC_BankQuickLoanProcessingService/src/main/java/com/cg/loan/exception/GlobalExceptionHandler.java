package com.cg.loan.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@ControllerAdvice //allows to handle exceptions across the whole application in one global handling component
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {
	
	
	//Customer Not Found Exception
	@ExceptionHandler(CustomerNotFoundException.class)
	public ResponseEntity<ExceptionResponse> handleCustomerException(CustomerNotFoundException ex) {
		
		ExceptionResponse response=new ExceptionResponse();
        response.setErrorCode("NOT FOUND");
        response.setErrorMessage(ex.getMessage());
        response.setTimestamp(LocalDateTime.now());
		 

        return new ResponseEntity<ExceptionResponse>(response, HttpStatus.NOT_FOUND);
		
	}
	//Loan Not Found Exception
		@ExceptionHandler(LoanNotFoundException.class)
		public ResponseEntity<ExceptionResponse> handleLoanException(LoanNotFoundException ex) {
			
			ExceptionResponse response=new ExceptionResponse();
	        response.setErrorCode("NOT FOUND");
	        response.setErrorMessage(ex.getMessage());
	        response.setTimestamp(LocalDateTime.now());
			 

	        return new ResponseEntity<ExceptionResponse>(response, HttpStatus.NOT_FOUND);
			
		}
		
	
	//Status Approval Exception
	@ExceptionHandler(LoanStatusApprovalException.class)
	public ResponseEntity<ExceptionResponse> handleLoanStatusException(LoanStatusApprovalException ex) {
		ExceptionResponse response=new ExceptionResponse();
        response.setErrorCode("NOT FOUND");
        response.setErrorMessage(ex.getMessage());
        response.setTimestamp(LocalDateTime.now());
		 

        return new ResponseEntity<ExceptionResponse>(response, HttpStatus.NOT_FOUND);
		
	}
	//Invalid Loan Application Exception
	@ExceptionHandler(InvalidLoanApplicationException.class)
	public ResponseEntity<ExceptionResponse> handleInvalidLoanApplicationException(InvalidLoanApplicationException ex) {
		ExceptionResponse response=new ExceptionResponse();
        response.setErrorCode("NOT FOUND");
        response.setErrorMessage(ex.getMessage());
        response.setTimestamp(LocalDateTime.now());
		 

        return new ResponseEntity<ExceptionResponse>(response, HttpStatus.NOT_FOUND);
		
	}

}
