package com.cg.loan.service;

import com.cg.loan.model.User;

/* User Service 
 * IUserServiceImpl implements IUserService 

 */


public interface IUserService  {
	// User addNewUser(User user) to add new user as admin,customer or LADOfficer
public  User addNewUser(User user);

}
