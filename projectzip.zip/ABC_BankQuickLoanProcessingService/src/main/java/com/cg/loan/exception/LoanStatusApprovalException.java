package com.cg.loan.exception;

@SuppressWarnings("serial")
public class LoanStatusApprovalException extends Exception {

	public LoanStatusApprovalException(String message) {
		super(message);

	}


}
